
import React from 'react';

export const Header: React.FC = () => {
  return (
    <header className="bg-slate-900/80 backdrop-blur-sm sticky top-0 z-10">
      <div className="container mx-auto px-4 md:px-8 py-4">
        <h1 className="text-3xl md:text-4xl font-bold text-center bg-clip-text text-transparent bg-gradient-to-r from-indigo-400 to-cyan-400">
          Gemini Virtual Try-On
        </h1>
        <p className="text-center text-slate-400 mt-2">
          See yourself in any outfit before you buy.
        </p>
      </div>
    </header>
  );
};
