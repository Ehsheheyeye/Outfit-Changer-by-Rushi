
import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="w-full mt-12 py-4">
      <div className="container mx-auto text-center text-slate-500 text-sm">
        <p>Powered by Google Gemini</p>
      </div>
    </footer>
  );
};
