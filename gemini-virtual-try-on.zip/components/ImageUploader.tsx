
import React, { useState, useCallback } from 'react';
import type { ImageData } from '../types';
import { UploadIcon } from './icons/UploadIcon';

interface ImageUploaderProps {
  id: string;
  onImageUpload: (imageData: ImageData) => void;
  icon: React.ReactNode;
  title: string;
  description: string;
}

export const ImageUploader: React.FC<ImageUploaderProps> = ({ id, onImageUpload, icon, title, description }) => {
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);

  const handleFileChange = useCallback((files: FileList | null) => {
    if (files && files[0]) {
      const file = files[0];
      if (!file.type.startsWith('image/')) {
        alert('Please upload an image file.');
        return;
      }

      const reader = new FileReader();
      reader.onload = () => {
        const base64 = (reader.result as string).split(',')[1];
        if (base64) {
          onImageUpload({ base64, mimeType: file.type });
          setPreviewUrl(URL.createObjectURL(file));
        }
      };
      reader.readAsDataURL(file);
    }
  }, [onImageUpload]);

  const onDragEnter = (e: React.DragEvent<HTMLLabelElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };
  const onDragLeave = (e: React.DragEvent<HTMLLabelElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };
  const onDragOver = (e: React.DragEvent<HTMLLabelElement>) => {
    e.preventDefault();
    e.stopPropagation();
  };
  const onDrop = (e: React.DragEvent<HTMLLabelElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    handleFileChange(e.dataTransfer.files);
  };

  return (
    <div className="w-full aspect-square">
      <label
        htmlFor={id}
        onDragEnter={onDragEnter}
        onDragLeave={onDragLeave}
        onDragOver={onDragOver}
        onDrop={onDrop}
        className={`flex flex-col items-center justify-center w-full h-full border-2 border-dashed rounded-lg cursor-pointer transition-colors duration-300
        ${isDragging ? 'border-indigo-500 bg-slate-700/50' : 'border-slate-600 bg-slate-800 hover:bg-slate-700/80'}
        ${previewUrl ? 'p-0 border-solid overflow-hidden' : 'p-5'}`}
      >
        {previewUrl ? (
          <img src={previewUrl} alt={title} className="w-full h-full object-cover" />
        ) : (
          <div className="flex flex-col items-center justify-center pt-5 pb-6 text-center">
            {icon}
            <p className="mb-2 text-sm font-semibold text-slate-300">{title}</p>
            <p className="text-xs text-slate-400">{description}</p>
            <div className="flex items-center mt-4 text-xs text-indigo-400">
                <UploadIcon className="w-4 h-4 mr-2" />
                <span>Click to upload or drag & drop</span>
            </div>
          </div>
        )}
        <input id={id} type="file" className="hidden" accept="image/*" onChange={(e) => handleFileChange(e.target.files)} />
      </label>
    </div>
  );
};
