
export interface ImageData {
  base64: string;
  mimeType: string;
}
