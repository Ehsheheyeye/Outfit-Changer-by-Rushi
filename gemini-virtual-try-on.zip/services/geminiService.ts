
import { GoogleGenAI, Modality } from "@google/genai";
import type { ImageData } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable is not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function virtualTryOn(userImage: ImageData, outfitImage: ImageData): Promise<string> {
  try {
    const model = 'gemini-2.5-flash-image-preview';

    const response = await ai.models.generateContent({
      model: model,
      contents: {
        parts: [
          {
            text: 'You are a virtual try-on assistant. The user provides two images. The first image is of a person, and the second is of an outfit. Your task is to generate a new, photorealistic image of the person from the first image wearing the outfit from the second image. Preserve the person\'s pose, body shape, and the background of their original photo as closely as possible. The resulting image should look natural and seamless.',
          },
          {
            inlineData: {
              data: userImage.base64,
              mimeType: userImage.mimeType,
            },
          },
          {
            inlineData: {
              data: outfitImage.base64,
              mimeType: outfitImage.mimeType,
            },
          },
        ],
      },
      config: {
        responseModalities: [Modality.IMAGE, Modality.TEXT],
      },
    });

    // Find the first image part in the response
    const imagePart = response.candidates?.[0]?.content?.parts?.find(part => part.inlineData);

    if (imagePart && imagePart.inlineData) {
      const base64ImageBytes = imagePart.inlineData.data;
      const mimeType = imagePart.inlineData.mimeType;
      return `data:${mimeType};base64,${base64ImageBytes}`;
    } else {
      // Check if there's a text part that might explain the failure
      const textPart = response.candidates?.[0]?.content?.parts?.find(part => part.text);
      const refusalReason = textPart?.text || 'The model did not return an image.';
      throw new Error(`Image generation failed: ${refusalReason}`);
    }
  } catch (error) {
    console.error('Error in virtualTryOn service:', error);
    if (error instanceof Error) {
        throw new Error(`API call failed: ${error.message}`);
    }
    throw new Error('An unexpected error occurred during the API call.');
  }
}
